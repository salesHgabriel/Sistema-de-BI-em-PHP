<?php 
  session_start();
  include 'Db.php';


  //inserção dos registros

  $nome = isset($_POST['nome']) == true ? $_POST['nome']:"";
  $sobrenome = isset($_POST['sobrenome']) == true ? $_POST['sobrenome']:"";
  $email = isset($_POST['email']) == true ? $_POST['email']:"";
  $senha = isset($_POST['senha']) == true ? $_POST['senha']:"";
  $funcao = isset($_POST['funcao']) == true ? $_POST['funcao']:"";
  


      $sql = "INSERT INTO `usuario`(`nome`, `sobrenome`, `email`, `senha`, `data_cadastro`, `funcao`) VALUES ('$nome','$sobrenome','$email','$senha','NOW()','$funcao');"; 

    $run_sql = mysqli_query($mysqli,$sql);


 

      if($run_sql) {
          $_SESSION['msg'] = "<p>Efetuado cadastro com sucesso </p>";
          header("Location: ../pages/registre.php");
          //
          
      }else{
     
         $_SESSION['msg'] = "<p>Erro ao cadastrar conta </p>";
       //  header("Location: ../pages/registre.php");

      }

  

 

 ?>