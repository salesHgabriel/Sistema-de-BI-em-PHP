<?php

namespace Db;

	$servidor   = "localhost";
	$user 		=  "root";
	$pass		=  "";
	$db_name	=  "estudo_php";
/**
* 
*/

	$mysqli =  mysqli_connect($servidor, $user , $pass, $db_name);	
	if (mysqli_connect_error()) {
				echo "Falha na conexao" . mysqli_connect_error();
			}		

